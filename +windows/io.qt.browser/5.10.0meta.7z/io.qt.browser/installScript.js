// 这个脚本是安装萌梦动作编辑器依赖项使用的
function Component( )
{
}
