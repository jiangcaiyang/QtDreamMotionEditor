// 这个脚本是安装萌梦动作编辑器使用的
function Component( )
{
}
