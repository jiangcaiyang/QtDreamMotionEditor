// 这个脚本是安装萌梦动作编辑器使用的
function Component( )
{
}

Component.prototype.createOperations = function ( )
{
    // 调用默认的实现
    component.createOperations( );

    // 调用VC再分发安装包
    switch ( systemInfo.productType )
    {
    case "windows":
        component.addOperation( "Execute",
                                "@TargetDir@/vcredist_x86.exe",
                                "/install",
                                "/quiet",
                                "/norestart",
                                "UNDOEXECUTE",
                                "@TargetDir@/vcredist_x86.exe",
                                "/uninstall",
                                "/quiet",
                                "/norestart" );
        break;
    }
}
